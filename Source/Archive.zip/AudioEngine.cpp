#include "AudioEngine.h"

AudioEngine::AudioEngine() = default;

AudioEngine::~AudioEngine()
{
    stop();
}

void AudioEngine::start()
{
    deviceManager.initialise (2, 2, nullptr, true);
    deviceManager.addAudioCallback (this);
}

void AudioEngine::stop()
{
    deviceManager.removeAudioCallback (this);
    deviceManager.closeAudioDevice();
}

juce::AudioDeviceManager& AudioEngine::getDeviceManager()
{
    return deviceManager;
}

// per-recorder monitoring
void AudioEngine::setRecorderMonitoringEnabled (bool enabled)
{
    recorder.setMonitoringEnabled (enabled);
}

bool AudioEngine::isRecorderMonitoringEnabled() const
{
    return recorder.isMonitoringEnabled();
}

// recording
void AudioEngine::armRecording()
{
    recorder.arm();
}

RecordingModule::StopResult AudioEngine::disarmRecording()
{
    return recorder.disarm();
}

// persistence stubs
void AudioEngine::restoreState() {}
void AudioEngine::saveState() {}

float AudioEngine::getInputRMS() const
{
    return inputRMS.load();
}

float AudioEngine::getInputPeak() const
{
    return inputPeak.load();
}

void AudioEngine::audioDeviceAboutToStart (juce::AudioIODevice* device)
{
    juce::BigInteger mask;
    mask.setBit (0); // input 1 for this recorder

    recorder.prepare (device->getCurrentSampleRate(), mask);
}

void AudioEngine::audioDeviceStopped()
{
}

void AudioEngine::audioDeviceIOCallbackWithContext (
    const float* const* input,
    int numInputChannels,
    float* const* output,
    int numOutputChannels,
    int numSamples,
    const juce::AudioIODeviceCallbackContext&)
{
    // clear outputs
    for (int ch = 0; ch < numOutputChannels; ++ch)
        if (output[ch] != nullptr)
            juce::FloatVectorOperations::clear (output[ch], numSamples);

    // meters
    float rms = 0.0f;
    float peak = 0.0f;
    int count = 0;

    for (int ch = 0; ch < numInputChannels; ++ch)
    {
        if (input[ch] == nullptr)
            continue;

        for (int i = 0; i < numSamples; ++i)
        {
            const float s = input[ch][i];
            rms += s * s;
            peak = juce::jmax (peak, std::abs (s));
        }

        count += numSamples;
    }

    if (count > 0)
        rms = std::sqrt (rms / (float) count);

    inputRMS.store (rms);
    inputPeak.store (peak);

    recorder.addMonitorSignal (input,
                               output,
                               numOutputChannels,
                               numSamples);

    recorder.process (input,
                      numInputChannels,
                      numSamples);
}
