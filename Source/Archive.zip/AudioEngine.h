#pragma once

#include <JuceHeader.h>
#include <atomic>
#include "RecordingModule.h"

class AudioEngine final : public juce::AudioIODeviceCallback
{
public:
    AudioEngine();
    ~AudioEngine() override;

    void start();
    void stop();

    juce::AudioDeviceManager& getDeviceManager();

    // per-recorder monitoring
    void setRecorderMonitoringEnabled (bool enabled);
    bool isRecorderMonitoringEnabled() const;

    // recording
    void armRecording();
    RecordingModule::StopResult disarmRecording();

    // persistence (stub)
    void restoreState();
    void saveState();

    // meters
    float getInputRMS() const;
    float getInputPeak() const;

    void audioDeviceAboutToStart (juce::AudioIODevice*) override;
    void audioDeviceStopped() override;

    void audioDeviceIOCallbackWithContext (
        const float* const* input,
        int numInputChannels,
        float* const* output,
        int numOutputChannels,
        int numSamples,
        const juce::AudioIODeviceCallbackContext&) override;

private:
    juce::AudioDeviceManager deviceManager;

    std::atomic<float> inputRMS  { 0.0f };
    std::atomic<float> inputPeak { 0.0f };

    RecordingModule recorder;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (AudioEngine)
};
