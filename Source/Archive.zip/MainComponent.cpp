#include "MainComponent.h"

MainComponent::MainComponent (AudioEngine& engine)
    : audioEngine (engine)
{
    addAndMakeVisible (monitorButton);
    monitorButton.addListener (this);
    monitorButton.setToggleState (
        audioEngine.isRecorderMonitoringEnabled(),
        juce::dontSendNotification);

    addAndMakeVisible (recordButton);
    recordButton.addListener (this);
    recordButton.setClickingTogglesState (true);

    deviceSelector = std::make_unique<juce::AudioDeviceSelectorComponent>(
        audioEngine.getDeviceManager(),
        1, 2,
        1, 2,
        false,
        false,
        false,
        false
    );

    addAndMakeVisible (*deviceSelector);

    startTimerHz (30);
    setSize (1000, 1000);
}

MainComponent::~MainComponent()
{
    stopTimer();
    monitorButton.removeListener (this);
    recordButton.removeListener (this);
}

void MainComponent::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colours::darkgrey);

    g.setColour (juce::Colours::white);
    g.setFont (18.0f);
    g.drawText ("SliceBot JUCE",
                0, 10, getWidth(), 30,
                juce::Justification::centred);

    // ==== INPUT VU METER ====
    const int meterX = 20;
    const int meterY = 60;
    const int meterW = getWidth() - 40;
    const int meterH = 20;

    g.setColour (juce::Colours::black);
    g.fillRect (meterX, meterY, meterW, meterH);

    g.setColour (juce::Colours::green);
    g.fillRect (meterX,
                meterY,
                (int) (meterW * rms),
                meterH);

    g.setColour (juce::Colours::red);
    g.drawLine ((float) (meterX + meterW * peak),
                (float) meterY,
                (float) (meterX + meterW * peak),
                (float) (meterY + meterH),
                2.0f);
}

void MainComponent::resized()
{
    monitorButton.setBounds (20, 100, 200, 30);
    recordButton .setBounds (240, 100, 120, 30);

    deviceSelector->setBounds (20,
                               150,
                               getWidth() - 40,
                               getHeight() - 170);
}

void MainComponent::buttonClicked (juce::Button* button)
{
    if (button == &monitorButton)
    {
        audioEngine.setRecorderMonitoringEnabled (
            monitorButton.getToggleState());
    }
    else if (button == &recordButton)
    {
        if (recordButton.getToggleState())
        {
            audioEngine.armRecording();
        }
        else
        {
            const auto result = audioEngine.disarmRecording();

            if (result == RecordingModule::StopResult::DeletedTooShort)
            {
                juce::AlertWindow::showMessageBoxAsync (
                    juce::AlertWindow::WarningIcon,
                    "Recording Too Short",
                    "Recordings must be at least 5 seconds long.",
                    "OK");
            }
        }
    }
}

void MainComponent::timerCallback()
{
    rms  = audioEngine.getInputRMS();
    peak = audioEngine.getInputPeak();
    repaint();
}
