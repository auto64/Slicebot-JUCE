#pragma once

#include <JuceHeader.h>
#include "AudioEngine.h"

class MainComponent final : public juce::Component,
                            private juce::Button::Listener,
                            private juce::Timer
{
public:
    explicit MainComponent (AudioEngine& engine);
    ~MainComponent() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void buttonClicked (juce::Button* button) override;
    void timerCallback() override;

    AudioEngine& audioEngine;

    juce::ToggleButton monitorButton { "Enable Monitoring" };
    juce::ToggleButton recordButton  { "Record" };

    std::unique_ptr<juce::AudioDeviceSelectorComponent> deviceSelector;

    float rms  = 0.0f;
    float peak = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainComponent)
};
