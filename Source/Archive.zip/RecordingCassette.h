#pragma once

#include <juce_core/juce_core.h>

class RecordingCassette
{
public:
    RecordingCassette() = default;
    ~RecordingCassette() = default;

    void reset() {}
};
