#include "RecordingModule.h"
#include "RecordingWriter.h"

RecordingModule::RecordingModule()
    : fifo (maxSamples)
{
    writer = new RecordingWriter();
}

void RecordingModule::prepare (double sr,
                               const juce::BigInteger& inputMask)
{
    sampleRate = sr;
    inputs = inputMask;

    const int channels = inputs.countNumberOfSetBits();
    jassert (channels > 0);

    fifoBuffer.setSize (channels, maxSamples);
    fifoBuffer.clear();

    fifo.reset();
    armed = false;
}

void RecordingModule::arm()
{
    if (armed)
        return;

    const int channels = inputs.countNumberOfSetBits();
    jassert (channels > 0);

    const auto dir =
        juce::File::getSpecialLocation (
            juce::File::userApplicationDataDirectory)
            .getChildFile ("SliceBotJUCE");

    dir.createDirectory();

    writer->start (dir.getChildFile ("recording_buffer_1.wav"),
                   sampleRate,
                   channels);

    armed = true;
}

RecordingModule::StopResult RecordingModule::disarm()
{
    if (! armed)
        return StopResult::Kept;

    armed = false;

    const double secondsRecorded =
        (double) writer->getSamplesWritten() / sampleRate;

    if (secondsRecorded < kMinSeconds)
    {
        writer->stopAndDelete();
        return StopResult::DeletedTooShort;
    }

    writer->stopAndKeep();
    return StopResult::Kept;
}

bool RecordingModule::isArmed() const
{
    return armed;
}

void RecordingModule::setMonitoringEnabled (bool enabled)
{
    monitoringEnabled = enabled;
}

bool RecordingModule::isMonitoringEnabled() const
{
    return monitoringEnabled;
}

void RecordingModule::process (const float* const* input,
                               int numInputChannels,
                               int numSamples)
{
    if (armed)
        writeToFifo (input, numInputChannels, numSamples);
}

void RecordingModule::addMonitorSignal (const float* const* input,
                                        float* const* output,
                                        int numOutputChannels,
                                        int numSamples) const
{
    if (! monitoringEnabled)
        return;

    int src = -1;
    for (int ch = 0; ch <= inputs.getHighestBit(); ++ch)
        if (inputs[ch]) { src = ch; break; }

    if (src < 0 || input[src] == nullptr)
        return;

    for (int out = 0; out < numOutputChannels; ++out)
        if (output[out])
            juce::FloatVectorOperations::add (output[out],
                                              input[src],
                                              numSamples);
}

void RecordingModule::writeToFifo (const float* const* input,
                                   int numInputChannels,
                                   int numSamples)
{
    int s1 = 0, z1 = 0, s2 = 0, z2 = 0;
    fifo.prepareToWrite (numSamples, s1, z1, s2, z2);

    if (z1 > 0)
    {
        int dst = 0;
        for (int ch = 0; ch < numInputChannels; ++ch)
            if (inputs[ch])
                fifoBuffer.copyFrom (dst++, s1, input[ch], z1);

        writer->push (fifoBuffer, s1, z1);
    }

    if (z2 > 0)
    {
        int dst = 0;
        for (int ch = 0; ch < numInputChannels; ++ch)
            if (inputs[ch])
                fifoBuffer.copyFrom (dst++, s2, input[ch] + z1, z2);

        writer->push (fifoBuffer, s2, z2);
    }

    fifo.finishedWrite (z1 + z2);
}
