#pragma once

#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>

// forward declaration ONLY
class RecordingWriter;

class RecordingModule
{
public:
    enum class StopResult
    {
        Kept,
        DeletedTooShort
    };

    RecordingModule();

    void prepare (double sampleRate,
                  const juce::BigInteger& inputMask);

    // recording
    void arm();
    StopResult disarm();
    bool isArmed() const;

    // monitoring
    void setMonitoringEnabled (bool enabled);
    bool isMonitoringEnabled() const;

    // audio processing
    void process (const float* const* input,
                  int numInputChannels,
                  int numSamples);

    void addMonitorSignal (const float* const* input,
                           float* const* output,
                           int numOutputChannels,
                           int numSamples) const;

private:
    static constexpr double kMinSeconds = 5.0;   // TEMP (25s later)
    static constexpr int    maxSeconds  = 600;
    static constexpr int    maxRate     = 48000;
    static constexpr int    maxSamples  = maxSeconds * maxRate;

    void writeToFifo (const float* const* input,
                      int numInputChannels,
                      int numSamples);

    juce::BigInteger inputs;

    juce::AudioBuffer<float> fifoBuffer;
    juce::AbstractFifo fifo;

    RecordingWriter* writer = nullptr; // owned in cpp

    double sampleRate = 0.0;
    bool armed = false;
    bool monitoringEnabled = false;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (RecordingModule)
};
