#pragma once

#include <juce_core/juce_core.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_audio_basics/juce_audio_basics.h>

class RecordingWriter : private juce::Thread
{
public:
    RecordingWriter()
        : juce::Thread ("RecordingWriter")
    {}

    ~RecordingWriter() override
    {
        stopAndKeep();
    }

    void start (const juce::File& targetFile,
                double sampleRate,
                int numChannels)
    {
        stopAndKeep();

        file = targetFile;
        file.deleteFile();
        file.create();

        auto stream = file.createOutputStream();
        jassert (stream != nullptr);

        juce::WavAudioFormat wav;
        writer.reset (wav.createWriterFor (stream.get(),
                                           sampleRate,
                                           (unsigned int) numChannels,
                                           32,
                                           {},
                                           0));
        stream.release(); // writer owns stream

        samplesWritten.store (0);
        startThread();
    }

    void push (const juce::AudioBuffer<float>& buffer,
               int startSample,
               int numSamples)
    {
        const juce::ScopedLock sl (lock);

        fifoBuffer.setSize (buffer.getNumChannels(),
                            numSamples,
                            false,
                            false,
                            true);

        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
            fifoBuffer.copyFrom (ch, 0,
                                 buffer, ch,
                                 startSample,
                                 numSamples);

        fifoSize = numSamples;
        fifo.signal();
    }

    // Keep file
    void stopAndKeep()
    {
        signalThreadShouldExit();
        waitForThreadToExit (2000);
        writer.reset();
        fifo.reset();
    }

    // Delete file
    void stopAndDelete()
    {
        stopAndKeep();
        if (file.existsAsFile())
            file.deleteFile();
    }

    juce::int64 getSamplesWritten() const
    {
        return samplesWritten.load();
    }

private:
    void run() override
    {
        while (! threadShouldExit())
        {
            fifo.wait (50);
            if (threadShouldExit())
                break;

            const juce::ScopedLock sl (lock);

            if (writer != nullptr && fifoSize > 0)
            {
                const float* const* channels =
                    fifoBuffer.getArrayOfReadPointers();

                writer->writeFromFloatArrays (channels,
                                              fifoBuffer.getNumChannels(),
                                              fifoSize);

                samplesWritten.fetch_add (fifoSize);
                fifoSize = 0;
            }
        }
    }

    juce::File file;
    std::unique_ptr<juce::AudioFormatWriter> writer;

    juce::AudioBuffer<float> fifoBuffer;
    int fifoSize = 0;

    juce::WaitableEvent fifo;
    juce::CriticalSection lock;

    std::atomic<juce::int64> samplesWritten { 0 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (RecordingWriter)
};
